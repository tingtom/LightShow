This package contains the TalkFX and ROCCAT Ryos // MK PRO Software Development Kit (SDK) for utilising the MK PRO single-key illumination feature and the RGB LED features from other ROCCAT devices in games and other software. 

Please refer to the PDF documentation in the ./docs folder for details on how to use it. 
The commandline tool for the Ryos is already present in this distribution, feel free to experiment with it!

Please refer to LICENSE.txt for licensing questions.