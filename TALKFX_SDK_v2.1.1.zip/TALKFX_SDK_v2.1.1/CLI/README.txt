============================================
The CLI is currently NOT FOR PRODUCTION USE!
============================================

ROCCAT Ryos // MK PRO -- Command Line Interface
(c)2013 - ROCCAT Studios Hamburg

  USAGE: RyosCLI.exe <method> <arguments>

  IMPORTANT: TalkFX needs to be running!

  METHODS:
    initsdk - activates SDK mode; required for setting LEDs
    stopsdk - deactivates SDK mode; gives LED control back to keyboard
    setsingleon [position] - lights up a single LED
        EXAMPLE: RyosCLI.exe setsingleon 1
    sendframe [(0|1)*] - sends a whole frame to the keyboard
        EXAMPLE: RyosCLI.exe sendframe 1001100101100111011101
    alloff - turns all LEDs off without leaving SDK mode

============================================
The CLI is currently NOT FOR PRODUCTION USE!
============================================