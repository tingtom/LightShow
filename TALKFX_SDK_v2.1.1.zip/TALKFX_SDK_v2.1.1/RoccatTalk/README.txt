This folder contains the current version of ROCCAT Talk at the time this SDK package was crafted. 

It is just included for convencience, so that you can get started right away.

However we suggest to check http://www.roccat.org/Support/Support-ROCCAT-Technology/ROCCAT-Talk-FX/
for updates frequently.

You need to install this software for the SDK to work.